# 输入说明

这批材料来自共享计量平台的脱敏演练库。tenant.csv是租户目录，meter_interval.csv是待装载的计量区间，actor_tenant_grant.csv记录登录角色与租户能力的对应关系。

access_contract.json给出隔离和日报边界，access_scenarios.csv列出安全人员需要留档的访问场景。starter/20_rls_broken.sql是现网脚本的简化副本，只用于识别原有缺口。

所有材料均为虚构样例，不含真实客户信息。input_data只读，完成后的SQL、访问结果和交接材料写入output目录。
