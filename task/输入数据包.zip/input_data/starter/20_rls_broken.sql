
-- 故障starter脚本，需要重构。
ALTER TABLE core.meter_interval ENABLE ROW LEVEL SECURITY;

CREATE POLICY everything_for_tenant
ON core.meter_interval
TO PUBLIC
USING (tenant_id = current_setting('app.tenant_id', true));

CREATE FUNCTION reporting.tenant_daily_summary(p_tenant text)
RETURNS TABLE (tenant_id text, interval_count bigint)
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT tenant_id, count(*)
  FROM core.meter_interval
  WHERE tenant_id = p_tenant
  GROUP BY tenant_id
$$;

GRANT EXECUTE ON FUNCTION reporting.tenant_daily_summary(text) TO PUBLIC;
